% Some arbitrary code you can replace!
% Done in MATLAB
% Alter this for other coding languages
% March, 2024

%% Keeping the House Clean

clear;
clc;
close all;

%% Setup Constants

g0 = 9.81;                                  % Garvitational Acceleration [m/s^2]    
G = 6.674e-11;                              % Gravitational Constant (Earth)
M = 5.9722e24;                              % Mass of Earth [kg]
R = 6371e3;                                 % Radius of Earth [m]

% Rocket Parameters for Questions 1 and 2 

T = 1000000;                                % Thrust [N]
epsilon = 0.10;                             % Structural Ratio
lambda = 0.01;                              % Payload Ratio
I_sp = 350;                                 % Specific Impulse [s]
m_total = 70948;                            % Total Mass of Rocket [kg]
m_pl = (lambda * m_total) / ( 1 + lambda);  % Payload Mass [kg]

rocket.diam = 3;                            % Diameter [m]
rocket.area = 0.25 * pi * rocket.diam^2;    % Cross-Sectional Frontal Area [m^2]
rocket.m_flow = - T / (I_sp*g0);            % Mass Flow Rate [kg/s] (assumed constant g)
rocket.m0 = m_total;                        % Initial Mass of Rocket  [kg]
rocket.m_f = m_pl * (1-epsilon) / lambda;   % Fuel Mass [kg]
rocket.m_e = rocket.m0 - rocket.m_f - m_pl; % Structural Mass [kg] 
rocket.CD = 0.82;                           % Approximated Drag Coefficient

% Rocket Paramteres for Question 3

m1_total = 284089;                          % Total Mass of Stage 1 [kg]
m1_inert = 21054;                           % Inert Mass of Stage 1 [kg]
m1_payload = 720.554;                       % Payload Mass [kg] (equivalent to m_pl)
t1_bo = 253;                                % Stage 1 Burnout Time [s]
altas.T1 = 3827000;                         % Thrust of Stage 1 [N]
altas.m_flow1 = -(m1_total - m1_inert + m1_payload) / t1_bo;  % Mass Flow Rate [kg/s] of Stage 1

m2_f = 18000;                               % Fuel Mass of Stage 2 [kg]
t2_bo = 400;                                % Stage 2 Burnout Time [s]
altas.T2 = 190000;                          % Thrust of Stage 2 [N]
altas.m_flow2 = -(m2_f) / t2_bo;            % Mass Flow Rate [kg/s] of Stage 2

atlas.diam = 5;                             % Adjusted Diameter [m]
altas.CD = 0.34;                            % Approximated Drag Coefficient
altas.area = 0.25 * pi * atlas.diam^2;      % Cross-Sectional Frontal Area [m^2]
